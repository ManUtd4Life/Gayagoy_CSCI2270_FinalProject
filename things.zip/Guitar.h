#ifndef GUITAR_H
#define GUITAR_H


class Guitar
{
    public:
        Guitar();
        ~Guitar();
    protected:
    private:
};

#endif // GUITAR_H

//1. create a chord list with a file
//2. display a chord
//3. add a chord
//4. delete a chord
//5. transpose up a selected chord
//6. transpose down a selected chord
//7. show a current list of chords
//8. clear all chords
//9. change a chord
//10. save changes
