# Gayagoy_CSCI2270_FinalProject

Project Summary:
	This program is a text-based chord book interface simulator. It stores data on chord structures for a standard 6 string guitar. The program will come with a base file with a standard list of chords for use. The program should be executed with the base file of chords so that it has something o run with. The user can now look up chords from the chord list and the program will display it for the user. The user can also edit the chord list by adding and deleting chords at will from the main menu interface. Users can also transpose any chord they like up or down. This project should help organize chords for new or expert guitarists.

How to Run:
	In order to run, load the zip file and run attached program with the attached text file. The program should prompt with a main menu that should display any available uses for the program.

Dependencies:

System Requirements:
Run using terminal preferably on vm software, available on any machine. 

Group Members:
Anh-khoa Than
Yash Parekh

Contributors:

Open issues/bugs:



